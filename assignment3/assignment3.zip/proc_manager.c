#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include<fcntl.h>
#include "apue.h"
#include "CommandNode.h"

int isEmpty(FILE *file){
    char ch;
    int count = 0;
    do{
        ch = fgetc(file);
        if(ch >= '0' && ch <= '9'){
            count++;
        }
    }while(ch != EOF);

    if(count > 0)           // file is not empty
        return 0;
    return 1;               // file is empty
}

int parse(char *line, char newString[20][20])
{
    int i,j,ctr;

    for (int i=0; i<20; i++)
    {
        for (int j = 0; j < 20; j++)
        {
            newString[i][j] = 0;
        }
    }
    j=0; ctr=0;
    for(i=0;i<=(strlen(line));i++)
    {
        // if space or NULL found, assign NULL into newString[ctr]
        if(line[i]==' '||line[i]=='\0' || line[i] == '\n')
        {
            newString[ctr][j]='\0';
            ctr++;  //for next word
            j=0;    //for next word, init index to 0
        }
        else
        {
            newString[ctr][j]=line[i];
            j++;
        }
    }

    for (i = ctr; i < 20; i++){
        newString[i][0] = '\0';
    }
    return ctr;
}

void prepareForExec(char buf[1][5], char *buf2[20], char newString[20][20], int count)
{
    buf[0][0] = '.';
    buf[0][1] = '.';
    buf[0][2] = 0;

    for(int i = 0; i < 20; i++)
    {
        buf2[i] = 0;    //reset
    }
    for(int m = 0; m < count; m++)
    {
        if(m < count - 1)
        {
            buf2[m] = newString[m];
        }
        else if(m == count - 1)
        {
            if(strcmp(newString[m], "sleep") == 0)
                buf2[count] = (char *)0;
            else
                buf2[count] = (char *)&buf[0][0];
        }
    }
}

int main(int argc, char* argv[])
{
    FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t read;
    int index = 1;
    int count = 0;
    pid_t pid;
    int status;
    // calculate the time taken
    struct  timespec start, finish;
    double  elapsed;
//    clock_t  t;
    char newString[20][20];
    int duration[20];
    char buf[1][5];
    char *buf2[20];
    FILE *fdout[20], *fderr[20];
    char fileNameOut[20], fileNameErr[20];

    if(argc == 1){
        printf("No input file!!!\n");
        exit(0);
    } else{
        // when we have input file
        char *cmdFileName = argv[1];
        fp = fopen(cmdFileName, "r");
        //cannot open file
        if (fp == NULL)
            exit(EXIT_FAILURE);
        else
        {
            // can open file
            // check if file is empty
            if(isEmpty(fp) == 1)
            {
                printf("File is empty!!!\n");
                exit(EXIT_SUCCESS);
            }
            // file is not empty
            fp = fopen(cmdFileName, "r");
            CommandNode *headNode;
            CommandNode *currNode;
            getline(&line, &len, fp);
            // run parse
            count = parse(line, newString);
            // create head node
            headNode = (CommandNode*)malloc(sizeof(CommandNode));
            CreateCommandNode(headNode, newString, index, count, NULL);
            // 1st loop
            while ((read = getline(&line, &len, fp)) != -1) {
                count = parse(line, newString);
                index++;
                currNode = (CommandNode*)malloc(sizeof(CommandNode));
                CreateCommandNode(currNode, newString, index, count, NULL);
                InsertCommandAfter(headNode, currNode);
            }

            // close cmdfile
            fclose(fp);
            if (line)
                free(line);

            // 2nd loop
            CommandNode *tmpNode;
            tmpNode = headNode;
            while (tmpNode != NULL)
            {
                // set start time for node
//                t = clock();
                clock_gettime(CLOCK_MONOTONIC, &start);
                tmpNode->starttime = start.tv_sec;
                //create child process
                pid = fork();
                if (pid < 0) {
                    fprintf(stderr, "fork error");
                    exit(1);
                } else if (pid == 0) {		/* child */
                    printf("PID: %d. Start command with index %d. Command: %s %s\n", getpid(), tmpNode->index, tmpNode->command[0], tmpNode->command[1]);
                    prepareForExec(buf, buf2, tmpNode->command, tmpNode->count);
                    execvp(buf2[0], buf2);
                    fprintf(stderr, "couldn't execute: %s", buf2[0]);
                    exit(127);
                }

                // parent process
                tmpNode->PID = pid;

                // file handling
                for(int i = 0; i < 20; i++)
                {
                    fileNameOut[i] = 0;
                    duration[i] = 1;
                }
                sprintf(fileNameOut, "%d.out", tmpNode->index);
                sprintf(fileNameErr, "%d.err", tmpNode->index);
                if(fdout[tmpNode->index] == NULL)
                {
                    fdout[tmpNode->index] = fopen(fileNameOut, "w+");
                    fderr[tmpNode->index] = fopen(fileNameErr, "w+");
                } else{
                    fdout[tmpNode->index] = fopen(fileNameOut, "a");
                    fderr[tmpNode->index] = fopen(fileNameErr, "a");
                }

                fprintf(fdout[tmpNode->index],"Starting command INDEX %d: chid PID %d of parent PPID %d. \n", tmpNode->index, pid, getppid());
                // close file
                fclose(fdout[tmpNode->index]);

                //go to next node
                tmpNode = GetNextCommand(tmpNode);
            }

            // 3rd loop
            //wait for complete processes
            // this will exit (wait returns -1)
            // when there is no more child process, parent process exits.
            //wait for complete process
            while((pid = wait(&status)) >= 0)
            {
                CommandNode *node;
                if(pid > 0)
                {
                    // finish time
//                    t = clock();
                    clock_gettime(CLOCK_MONOTONIC, &finish);
                    // search linked list for the node that corresponds to pid
                    node = FindCommand(headNode, pid);

                    // file handling
                    sprintf(fileNameOut, "%d.out", node->index);
                    if(fdout[node->index] == NULL)
                    {
                        fdout[node->index] = fopen(fileNameOut, "w+");
                    } else{
                        fdout[node->index] = fopen(fileNameOut, "a");
                    }

                    fprintf(stderr, "Process with PID %d terminated.\n", pid);
                    // find elapsed time
                    elapsed = finish.tv_sec - node->starttime;

                    if(WIFEXITED(status))
                    {
                        fprintf(fderr[node->index], "Exited with exit code =  %d.\n", WEXITSTATUS(status));
                        fprintf(fdout[node->index], "Finish at %f, runtime duration = %d\n", (elapsed * duration[node->index]), duration[node->index]);
                    }
                    else if(WIFSIGNALED(status))
                    {
                        fprintf(fderr[node->index], "Killed by signal: %d\n", WTERMSIG(status));
                    }

                    if(elapsed > 2.0)           // run time > 2s => restart process
                    {
                        // record start time
                        clock_gettime(CLOCK_MONOTONIC, &start);
                        node->starttime = start.tv_sec;  // assign new start time to node
                        // restart the process
                        duration[node->index]++;
                        pid = fork();
                        if (pid < 0) {
                            fprintf(stderr, "fork error");
                            exit(1);
                        } else if (pid == 0) {		/* child */
                            prepareForExec(buf, buf2, node->command, node->count);
                            execvp(buf2[0], buf2);
                            fprintf(fderr[node->index], "couldn't execute or unknown command: %s", buf2[0]);
                            exit(127);
                        }

                        //parent process
                        node->PID = pid;

                    } else{
                        fprintf(fderr[node->index], "spawning too fast\n");
                    }
                }
            }
        }
    }

    printf("Done!\n");
    exit(0);
}
